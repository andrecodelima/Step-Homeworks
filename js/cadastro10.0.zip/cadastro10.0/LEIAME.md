
        Crie uma págia com um navbar que tenha os seguintes links:
        cadastro    - Exibe um formulário de cadastro de veículos
        Resultados  - Exibe os cadastrados
        
        --- Não precisa fazer as páginas funcionarem, o treino é 
            para a navegação entre os elementos.

            No formulário deverá ter uma forma de escolher entre:
            Carro,
            Moto    (Tem Cilindradas),
            Barcos  (Tem pés)

            Todos Terão: 
            Modelo, cor e fabricante.

            "Se escolher moto, tem que esconder barco e carro"
