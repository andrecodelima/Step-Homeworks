/////////////////////// CADASTRO DE VEÍCULOS \\\\\\\\\\\\\\\\\\\\\\\\
        
    /*|------- CRIAÇÃO DE CLASSE - INÍCIO ------ |*/
class Cadastro{
    constructor(pTipo, pModelo, pCor, pFabricante, pCilindrada, pPes){

        this.tipo           = pTipo
        this.modelo         = pModelo
        this.cor            = pCor
        this.fabricante     = pFabricante
        this.cilindrada     = pCilindrada
        this.pes            = pPes

    }

    cardCarro = function(){
        let card = "<div class='card'>"                       + 

                        "Tipo: "          + this.tipo         + "<br>"   +
                        "Modelo: "        + this.modelo       + "<br>"   +
                        "Cor: "           + this.cor          + "<br>"   +
                        "Fabricante: "    + this.fabricante   + "<br>"   +
            
                    "</div>"
        return card
    }

    cardMoto = function(){
        let card = "<div class='card'>"                       + 

                        "Tipo: "          + this.tipo         + "<br>"   +
                        "Modelo: "        + this.modelo       + "<br>"   +
                        "Cor: "           + this.cor          + "<br>"   +
                        "Fabricante: "    + this.fabricante   + "<br>"   +
                        "Cilindadras: "   + this.cilindrada   + "<br>"   +

                    "</div>"
        return card
    }

    cardBarco = function(){
        let card = "<div class='card'>"                       + 

                        "Tipo: "          + this.tipo         + "<br>"   +
                        "Modelo: "        + this.modelo       + "<br>"   +
                        "Cor: "           + this.cor          + "<br>"   +
                        "Fabricante: "    + this.fabricante   + "<br>"   +
                        "Pés: "           + this.pes          + "<br>"   +
            
                    "</div>"
        return card
    }


}
    /*|------- CRIAÇÃO DE CLASSE - FIM ------ |*/

    /*|------- VAR GLOBAIS - INÍCIO ------ |*/

var banco           = []

var tipo            = document.getElementById('inputTipo')
var modelo          = document.getElementById('inputModelo')
var cor             = document.getElementById('inputCor')
var fabricante      = document.getElementById('inputFaber')
var cilindrada      = document.getElementById('inputCilindrada')
var pes             = document.getElementById('inputPes')

var limpa           = document.getElementById('formulario')
var div             = document.getElementById('resposta')



    /*|------- FUNÇÕES GLOBAIS  ------ |*/

    /*|------- FUNÇÃO CADASTRAR ------ |*/

function cadastrar(){
    
    switch(tipo.value){
        case "carro":
            banco.push(new Cadastro(tipo.value, modelo.value, cor.value, fabricante.value))
            tipo.setAttribute('enable')
            break

        case "moto":
            banco.push(new Cadastro(tipo.value, modelo.value, cor.value, fabricante.value, cilindrada.value))
            tipo.setAttribute('enable')
            // for(c in banco){
            //     cartoes += (banco[c].cardMoto())
            // }document.write(cartoes)
            break

        case "barco": 
            banco.push(new Cadastro(tipo.value, modelo.value, cor.value, fabricante.value, pes.value))
            tipo.setAttribute('enable')
            break

        default:
            alert('Tipo de veículo inválido')
    }
    
    limpa.reset()
}


    /*|------- FUNÇÃO EXIBIR ------ |*/

function exibir(){
    let tipo = document.getElementById('inputTipo')
    let cartoes = ''

    switch(tipo.value){
        
        case 'carro':        
            for(c in banco){
                cartoes += (banco[c].cardCarro())
            }div.innerHTML = cartoes
        break

        case 'moto':
            for(c in banco){
                cartoes += (banco[c].cardMoto())
            }div.innerHTML = cartoes
        break

        case 'barco':
            for(c in banco){
                cartoes += (banco[c].cardBarco())
            }div.innerHTML = cartoes
        break

        default:
            alert('Exiba um cadastro válido')
    }

}


    /*|------- FUNÇÃO EXIBIR TIPO ------ |*/

function exibirTipo(){
    let divMoto = document.getElementById('box-moto')
    let divBarco = document.getElementById('box-barco')
    let tipo = document.getElementById('inputTipo')
   
    switch(tipo.value){
        case 'moto':
            divMoto.style.display = 'block'
            divBarco.style.display = 'none'
        break

        case 'barco':
            divMoto.style.display = 'none'
            divBarco.style.display = 'block'
        break

        case 'carro':
            divMoto.style.display = 'none'
            divBarco.style.display = 'none'
        break
   }
}
